var DhtmlXQimgpath=(location.hostname=='localhost'||location.hostname=='192.168.0.2')?('http://'+location.hostname+'/hldcg/search/'):('http://www.dpxq.com/DhtmlXQ_www_dpxq_com/');
var ads = new Array();
ads[0] = '<a href="http://www.dpxq.com/hldcg/shop/yindianka.htm" target="_blank" style="color:#00f;">\u5F08\u5929\u767D\u91D1\u6703\u54E12\u5E74100\u5143</a>';
ads[1] = '<a href="http://www.dpxq.com/hldcg/dhtmlxq/?s=dhtml" target="_blank" style="color:#f00;">\u9EDE\u6B64\u8F49\u63DB DhtmlXQ\u68CB\u8B5C</a>';
ads[2] = '<a href="http://www.dpxq.com/hldcg/shop/yindianka.htm" target="_blank" style="color:#00f;">\u5F08\u5929\u9EC3\u91D1\u6703\u54E1\u5E74\u536150\u5143</a>';
ads[3] = '<a href="http://www.dpxq.com/hldcg/search/?s=dhtml" target="_blank" style="color:#00f;">\u68CB\u8B5C\u5009\u5EAB</a> <a href="http://www.dpxq.com/hldcg/shop/vip.htm" target="_blank" style="color:#00f;">\u8CFC\u8CB7VIP\u6703\u54E1</a>';
var ads_dpxq = '<div style="margin-left:3px;">'+ads.join('<br>')+'</div>';
var DhtmlXQimgpath=(location.hostname=='localhost'||location.hostname=='192.168.0.2')?('http://'+location.hostname+'/hldcg/search/'):('http://www.dpxq.com/DhtmlXQ_www_dpxq_com/');
var ads = new Array();
ads[0] = '<a href="http://www.dpxq.com/hldcg/shop/yindianka.htm?s=dhtml" target="_blank" style="color:#00f;">\u5F08\u5929\u767D\u91D1\u4F1A\u54582\u5E74100\u5143</a>';
ads[1] = '<a href="http://www.dpxq.com/hldcg/dhtmlxq/?s=dhtml" target="_blank" style="color:#f00;">\u70B9\u6B64\u8F6C\u6362 DhtmlXQ\u68CB\u8C31</a>';
ads[2] = '<a href="http://www.dpxq.com/hldcg/shop/yindianka.htm?s=dhtml" target="_blank" style="color:#00f;">\u5F08\u5929\u9EC4\u91D1\u4F1A\u5458\u5E74\u536150\u5143</a>';
ads[3] = '<a href="http://www.dpxq.com/hldcg/search/?s=dhtml" target="_blank" style="color:#00f;">\u68CB\u8C31\u4ED3\u5E93</a> <a href="http://www.dpxq.com/hldcg/shop/vip.htm?s=dhtml" target="_blank" style="color:#00f;">\u8D2D\u4E70VIP\u4F1A\u5458</a>';
var ads_dpxq = '<div style="margin-left:3px;">'+ads.join('<br>')+'</div>';